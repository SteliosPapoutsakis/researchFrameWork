/*
This class is used to describe a variable in verilog
This class takes the info and prints the appropriate
verilog code

@author Stelios Papoutsakis
*/

import java.util.ArrayList;

public class Var extends VerilogComp {
    private boolean isSelectSignal; // if it is a select signal for Muxes


    public Var(String name, int bitSize, boolean isInput, boolean isOutput, boolean isSelectSignal) {
        super(name, bitSize, isInput, isOutput);
        this.isSelectSignal = isSelectSignal;
    }

    /*
Overriden methods which write verilog code
 */

    @Override
    public String defineInput() {
        if (isInput()) {
            int bit = this.getBitSize() - 1;
            String str = "input ";
            if (this.getBitSize() > 1)
                str += "[" + bit + ":0] ";
            return str += this.getName() + ";";
        }
        return "";
    }

    @Override
    public String defineOutput() {
        if (isOutput()) {
            int bit = this.getBitSize() - 1;
            String str = "output ";
            if (this.getBitSize() > 1)
                str += "[" + bit + ":0] ";
            return str += this.getName() + ";";
        }
        return "";

    }



    // if it is a select signal break up the var into Mux_select signals
    public String defineAssign(ArrayList<Mux> comp) {
        if (this.isSelectSignal) {
            String str = "";
            int start = 0;
            int end;
            for (int i = 0; i < comp.size(); i++) {
                int size = comp.get(i).getSelectionSize() - 1;
                end = start + comp.get(i).getSelectionSize() - 1;
                String temp = "";
                String temp2 = "";
                if(size > 1)
                {
                 temp = "[" + size + ":0]" ;
                }
                if(comp.size() > 1)
                    temp2 = "[" + start + "]";
                if(start != end)
                    temp2 = "[" + start + ":" + end + "]";

                str += "assign " + comp.get(i).getName() + "_Select" + temp +
                        " = " + this.getName() + temp2+ ";";
                str += "\n";
                start += comp.get(i).getSelectionSize();
            }


            return str;
        }
        return "";
    }

    public boolean isSelectSignal() {
        return isSelectSignal;
    }






    public void setName(int start, int end)
    {
         this.setName(this.getName() + "[" + start + ":" + end + "]");

    }


}
