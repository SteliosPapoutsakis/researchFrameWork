import java.util.ArrayList;
import java.util.HashMap;

public class State {
    private HashMap<Var, Integer> assignments;
    private HashMap<Var, Integer> conditions;
    private HashMap<Mux, ArrayList<VerilogComp>> select;
    private int selectSize;
    private int stateSize;


    private String stateNumberBinary;
    private int stateNumber;

    public State(int stateNumber, HashMap<Var, Integer> assignments, HashMap<Var, Integer> conditions) {
        this.assignments = assignments;
        this.conditions = conditions;
        this.stateNumberBinary = null;
        this.stateNumber = stateNumber;
    }


    public String defState() {
        StringBuilder str = new StringBuilder(this.stateNumberBinary + ": begin \n");
        int i = 0;
        for (Var var : this.conditions.keySet()) {
            if (i < 1)
                str.append("\t" + defCondition(var, this.conditions.get(var), true));
            else
                str.append("\t" + defCondition(var, this.conditions.get(var), false));
            i++;
        }

        for (Var var : this.assignments.keySet())
            str.append("\t" + defAssignemts(var, this.assignments.get(var)));

        str.append("\t" + defMuxSelect(this.selectSize));


        return str.toString();

    }


    public String defCondition(Var var, int state, boolean isFirst) {
        String stateStr = IntToBinary.printToBinary(state, this.stateSize);
        StringBuilder str = new StringBuilder();
        if (var.getName().equals("NO_CONDITIONS")) {
            str.append("\t\tnext_state = " + stateStr + ";\n");
            return str.toString();
        }
        String elseif = "";
        if (!isFirst)
            elseif = "else ";
        str.append(elseif + "if(" + var.getName() + ")\n");
        str.append("\tbegin\n");
        str.append("\t\tnext_state = " + stateStr + ";\n");
        str.append("\tend\n");
        return str.toString();

    }

    public String defAssignemts(Var var, int number) {
        if (var.getBitSize() > 1) {
            String numberStr = IntToBinary.printToBinary(number, var.getBitSize());
            var.setName(var.getBitSize() - 1, 0);
            return var.getName() + " = " + numberStr + ";\n";
        }
        return var.getName() + " = " + number + ";\n";

    }

    public String defMuxSelect(int size) {

        StringBuilder str = new StringBuilder();
        for (Mux mux : this.select.keySet()) {
            for (int i = 0; i < mux.getInputs().length; i++) {
                if (mux.getInputs()[i].getName().equals(this.select.get(mux).get(this.stateNumber).getName())) {
                    str.append(IntToBinary.strickBinary(i, mux.getSelectionSize()));
                    break;
                }
            }

        }

        String temp = "SelectionBits";
        if (size > 1) {
            size--;
            temp += "[" + size + ":0]";
        }

        return temp + " = " + str.length() + "'b" + str.toString() + ";";

    }


    public String getStateNumber() {
        return stateNumberBinary;
    }

    public void setSelect(HashMap<Mux, ArrayList<VerilogComp>> select, int size) {

        this.select = select;
        this.selectSize = size;
    }

    public void setbinarystatenumber(int sizeOfAllStates) {
        this.stateNumberBinary = IntToBinary.printToBinary(this.stateNumber, sizeOfAllStates);
        this.stateSize = sizeOfAllStates;
    }

//    public static void main(String[] args) {
//        HashMap<Var, String> assignments = new HashMap<>();
////        Var var = new Var("busy", 1, false, false, false, false, false);
////        Var var2 = new Var("busy", 1, false, false, false, false, false);
////        Var var3 = new Var("busy", 3, false, false, false, false, false);
//
//        assignments.put(var, new FixedNumber(0, var.getBitSize()).getName());
//        assignments.put(var2, new FixedNumber(1, var2.getBitSize()).getName());
//        assignments.put(var3, new FixedNumber(3, var3.getBitSize()).getName());
//
//        HashMap<Var, String> conditions = new HashMap<>();
//        Var var4 = new Var("flag", 1, false, true, false, false, false);
//        conditions.put(var4, new FixedNumber(3, 4).getName());
//
//       // State state = new State(new FixedNumber(1, 1).getName(), assignments, conditions);
//
//
//        HashMap<Mux, VerilogComp> select = new HashMap<>();
//        Mux mux1 = new Mux(4, 4, new Register("sas", 4, false, false));
//        mux1.addInput(new FixedNumber(3, 2), 0);
//        mux1.addInput(new FixedNumber(2, 2), 1);
//
//        select.put(mux1,mux1.getInputs()[1]);
//
//      //  state.setSelect(select);
//        //System.out.println(state.defMuxSelect(2));


}



