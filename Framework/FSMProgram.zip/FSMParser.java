// Generated from C:/research/javalib/FSM/src\FSM.g4 by ANTLR 4.7
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class FSMParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, Clk=8, RESET=9, 
		EQUALS=10, GREATERTHAN=11, LESSTHAN=12, NOT=13, INPUT=14, OUTPUT=15, ASSIGN=16, 
		COMMA=17, REG=18, VAR=19, NAME=20, STATENUMBER=21, NEGATIVEINT=22, INT=23, 
		WHITESPACE=24, NEWLINE=25;
	public static final int
		RULE_fsm = 0, RULE_next_state = 1, RULE_condition = 2, RULE_state = 3, 
		RULE_register_assign = 4, RULE_adder_assign = 5, RULE_integer = 6, RULE_component = 7, 
		RULE_register = 8, RULE_var = 9, RULE_var_assign = 10, RULE_var_assigment = 11, 
		RULE_reg_assigment = 12, RULE_inputs = 13, RULE_outputs = 14;
	public static final String[] ruleNames = {
		"fsm", "next_state", "condition", "state", "register_assign", "adder_assign", 
		"integer", "component", "register", "var", "var_assign", "var_assigment", 
		"reg_assigment", "inputs", "outputs"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'Start FSM'", "'End FSM'", "'Next State'", "'if'", "'Define'", 
		"'End'", "'+'", "'C_'", "'R_'", "'equals'", "'greater than'", "'less than'", 
		"'not equals'", "'input'", "'output'", null, "','", "'Reg'", "'Var'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, null, null, null, null, null, null, null, "Clk", "RESET", "EQUALS", 
		"GREATERTHAN", "LESSTHAN", "NOT", "INPUT", "OUTPUT", "ASSIGN", "COMMA", 
		"REG", "VAR", "NAME", "STATENUMBER", "NEGATIVEINT", "INT", "WHITESPACE", 
		"NEWLINE"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "FSM.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public FSMParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class FsmContext extends ParserRuleContext {
		public InputsContext inputs() {
			return getRuleContext(InputsContext.class,0);
		}
		public OutputsContext outputs() {
			return getRuleContext(OutputsContext.class,0);
		}
		public TerminalNode EOF() { return getToken(FSMParser.EOF, 0); }
		public List<StateContext> state() {
			return getRuleContexts(StateContext.class);
		}
		public StateContext state(int i) {
			return getRuleContext(StateContext.class,i);
		}
		public FsmContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fsm; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterFsm(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitFsm(this);
		}
	}

	public final FsmContext fsm() throws RecognitionException {
		FsmContext _localctx = new FsmContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_fsm);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(30);
			match(T__0);
			setState(31);
			inputs();
			setState(32);
			outputs();
			setState(34); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(33);
				state();
				}
				}
				setState(36); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==STATENUMBER );
			setState(38);
			match(T__1);
			setState(39);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Next_stateContext extends ParserRuleContext {
		public TerminalNode STATENUMBER() { return getToken(FSMParser.STATENUMBER, 0); }
		public ConditionContext condition() {
			return getRuleContext(ConditionContext.class,0);
		}
		public Next_stateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_next_state; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterNext_state(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitNext_state(this);
		}
	}

	public final Next_stateContext next_state() throws RecognitionException {
		Next_stateContext _localctx = new Next_stateContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_next_state);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(41);
			match(T__2);
			setState(43);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(42);
				condition();
				}
			}

			setState(45);
			match(STATENUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConditionContext extends ParserRuleContext {
		public Token opp;
		public ComponentContext component() {
			return getRuleContext(ComponentContext.class,0);
		}
		public RegisterContext register() {
			return getRuleContext(RegisterContext.class,0);
		}
		public VarContext var() {
			return getRuleContext(VarContext.class,0);
		}
		public TerminalNode GREATERTHAN() { return getToken(FSMParser.GREATERTHAN, 0); }
		public TerminalNode LESSTHAN() { return getToken(FSMParser.LESSTHAN, 0); }
		public TerminalNode EQUALS() { return getToken(FSMParser.EQUALS, 0); }
		public TerminalNode NOT() { return getToken(FSMParser.NOT, 0); }
		public ConditionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterCondition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitCondition(this);
		}
	}

	public final ConditionContext condition() throws RecognitionException {
		ConditionContext _localctx = new ConditionContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_condition);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(47);
			match(T__3);
			setState(50);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				{
				setState(48);
				register();
				}
				break;
			case 2:
				{
				setState(49);
				var();
				}
				break;
			}
			setState(52);
			((ConditionContext)_localctx).opp = _input.LT(1);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << EQUALS) | (1L << GREATERTHAN) | (1L << LESSTHAN) | (1L << NOT))) != 0)) ) {
				((ConditionContext)_localctx).opp = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(53);
			component();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StateContext extends ParserRuleContext {
		public TerminalNode STATENUMBER() { return getToken(FSMParser.STATENUMBER, 0); }
		public List<Var_assignContext> var_assign() {
			return getRuleContexts(Var_assignContext.class);
		}
		public Var_assignContext var_assign(int i) {
			return getRuleContext(Var_assignContext.class,i);
		}
		public List<Next_stateContext> next_state() {
			return getRuleContexts(Next_stateContext.class);
		}
		public Next_stateContext next_state(int i) {
			return getRuleContext(Next_stateContext.class,i);
		}
		public List<Register_assignContext> register_assign() {
			return getRuleContexts(Register_assignContext.class);
		}
		public Register_assignContext register_assign(int i) {
			return getRuleContext(Register_assignContext.class,i);
		}
		public List<Adder_assignContext> adder_assign() {
			return getRuleContexts(Adder_assignContext.class);
		}
		public Adder_assignContext adder_assign(int i) {
			return getRuleContext(Adder_assignContext.class,i);
		}
		public StateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_state; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterState(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitState(this);
		}
	}

	public final StateContext state() throws RecognitionException {
		StateContext _localctx = new StateContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_state);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(55);
			match(STATENUMBER);
			setState(56);
			match(T__4);
			setState(62);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ASSIGN) | (1L << REG) | (1L << VAR) | (1L << INT))) != 0)) {
				{
				setState(60);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
				case 1:
					{
					{
					setState(57);
					register_assign();
					}
					}
					break;
				case 2:
					{
					{
					setState(58);
					adder_assign();
					}
					}
					break;
				case 3:
					{
					setState(59);
					var_assign();
					}
					break;
				}
				}
				setState(64);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(68);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__2) {
				{
				{
				setState(65);
				next_state();
				}
				}
				setState(70);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(71);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Register_assignContext extends ParserRuleContext {
		public RegisterContext register() {
			return getRuleContext(RegisterContext.class,0);
		}
		public Reg_assigmentContext reg_assigment() {
			return getRuleContext(Reg_assigmentContext.class,0);
		}
		public Adder_assignContext adder_assign() {
			return getRuleContext(Adder_assignContext.class,0);
		}
		public Register_assignContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_register_assign; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterRegister_assign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitRegister_assign(this);
		}
	}

	public final Register_assignContext register_assign() throws RecognitionException {
		Register_assignContext _localctx = new Register_assignContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_register_assign);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(73);
			register();
			setState(76);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
			case 1:
				{
				setState(74);
				reg_assigment();
				}
				break;
			case 2:
				{
				setState(75);
				adder_assign();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Adder_assignContext extends ParserRuleContext {
		public TerminalNode ASSIGN() { return getToken(FSMParser.ASSIGN, 0); }
		public List<ComponentContext> component() {
			return getRuleContexts(ComponentContext.class);
		}
		public ComponentContext component(int i) {
			return getRuleContext(ComponentContext.class,i);
		}
		public Adder_assignContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_adder_assign; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterAdder_assign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitAdder_assign(this);
		}
	}

	public final Adder_assignContext adder_assign() throws RecognitionException {
		Adder_assignContext _localctx = new Adder_assignContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_adder_assign);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(78);
			match(ASSIGN);
			setState(79);
			component();
			setState(80);
			match(T__6);
			setState(81);
			component();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntegerContext extends ParserRuleContext {
		public Token opp;
		public TerminalNode INT() { return getToken(FSMParser.INT, 0); }
		public TerminalNode NEGATIVEINT() { return getToken(FSMParser.NEGATIVEINT, 0); }
		public IntegerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_integer; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterInteger(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitInteger(this);
		}
	}

	public final IntegerContext integer() throws RecognitionException {
		IntegerContext _localctx = new IntegerContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_integer);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(83);
			((IntegerContext)_localctx).opp = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==NEGATIVEINT || _la==INT) ) {
				((IntegerContext)_localctx).opp = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ComponentContext extends ParserRuleContext {
		public IntegerContext integer() {
			return getRuleContext(IntegerContext.class,0);
		}
		public RegisterContext register() {
			return getRuleContext(RegisterContext.class,0);
		}
		public VarContext var() {
			return getRuleContext(VarContext.class,0);
		}
		public ComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_component; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitComponent(this);
		}
	}

	public final ComponentContext component() throws RecognitionException {
		ComponentContext _localctx = new ComponentContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_component);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(88);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				{
				setState(85);
				integer();
				}
				break;
			case 2:
				{
				setState(86);
				register();
				}
				break;
			case 3:
				{
				setState(87);
				var();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RegisterContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(FSMParser.NAME, 0); }
		public TerminalNode INT() { return getToken(FSMParser.INT, 0); }
		public RegisterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_register; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterRegister(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitRegister(this);
		}
	}

	public final RegisterContext register() throws RecognitionException {
		RegisterContext _localctx = new RegisterContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_register);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(91);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==INT) {
				{
				setState(90);
				match(INT);
				}
			}

			setState(93);
			match(REG);
			setState(94);
			match(NAME);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VarContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(FSMParser.NAME, 0); }
		public TerminalNode INT() { return getToken(FSMParser.INT, 0); }
		public TerminalNode Clk() { return getToken(FSMParser.Clk, 0); }
		public TerminalNode RESET() { return getToken(FSMParser.RESET, 0); }
		public VarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterVar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitVar(this);
		}
	}

	public final VarContext var() throws RecognitionException {
		VarContext _localctx = new VarContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_var);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(97);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==INT) {
				{
				setState(96);
				match(INT);
				}
			}

			setState(99);
			match(VAR);
			setState(101);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==Clk) {
				{
				setState(100);
				match(Clk);
				}
			}

			setState(104);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==RESET) {
				{
				setState(103);
				match(RESET);
				}
			}

			setState(106);
			match(NAME);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Var_assignContext extends ParserRuleContext {
		public VarContext var() {
			return getRuleContext(VarContext.class,0);
		}
		public Var_assigmentContext var_assigment() {
			return getRuleContext(Var_assigmentContext.class,0);
		}
		public Var_assignContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var_assign; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterVar_assign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitVar_assign(this);
		}
	}

	public final Var_assignContext var_assign() throws RecognitionException {
		Var_assignContext _localctx = new Var_assignContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_var_assign);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(108);
			var();
			{
			setState(109);
			var_assigment();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Var_assigmentContext extends ParserRuleContext {
		public TerminalNode ASSIGN() { return getToken(FSMParser.ASSIGN, 0); }
		public IntegerContext integer() {
			return getRuleContext(IntegerContext.class,0);
		}
		public Var_assigmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var_assigment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterVar_assigment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitVar_assigment(this);
		}
	}

	public final Var_assigmentContext var_assigment() throws RecognitionException {
		Var_assigmentContext _localctx = new Var_assigmentContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_var_assigment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(111);
			match(ASSIGN);
			{
			setState(112);
			integer();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Reg_assigmentContext extends ParserRuleContext {
		public TerminalNode ASSIGN() { return getToken(FSMParser.ASSIGN, 0); }
		public IntegerContext integer() {
			return getRuleContext(IntegerContext.class,0);
		}
		public RegisterContext register() {
			return getRuleContext(RegisterContext.class,0);
		}
		public Reg_assigmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_reg_assigment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterReg_assigment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitReg_assigment(this);
		}
	}

	public final Reg_assigmentContext reg_assigment() throws RecognitionException {
		Reg_assigmentContext _localctx = new Reg_assigmentContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_reg_assigment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(114);
			match(ASSIGN);
			setState(117);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
			case 1:
				{
				setState(115);
				integer();
				}
				break;
			case 2:
				{
				setState(116);
				register();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InputsContext extends ParserRuleContext {
		public TerminalNode INPUT() { return getToken(FSMParser.INPUT, 0); }
		public List<IntegerContext> integer() {
			return getRuleContexts(IntegerContext.class);
		}
		public IntegerContext integer(int i) {
			return getRuleContext(IntegerContext.class,i);
		}
		public List<RegisterContext> register() {
			return getRuleContexts(RegisterContext.class);
		}
		public RegisterContext register(int i) {
			return getRuleContext(RegisterContext.class,i);
		}
		public List<VarContext> var() {
			return getRuleContexts(VarContext.class);
		}
		public VarContext var(int i) {
			return getRuleContext(VarContext.class,i);
		}
		public InputsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inputs; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterInputs(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitInputs(this);
		}
	}

	public final InputsContext inputs() throws RecognitionException {
		InputsContext _localctx = new InputsContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_inputs);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(119);
			match(INPUT);
			setState(126); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				setState(126);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
				case 1:
					{
					setState(120);
					integer();
					setState(121);
					register();
					}
					break;
				case 2:
					{
					setState(123);
					integer();
					setState(124);
					var();
					}
					break;
				}
				}
				setState(128); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEGATIVEINT || _la==INT );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OutputsContext extends ParserRuleContext {
		public TerminalNode OUTPUT() { return getToken(FSMParser.OUTPUT, 0); }
		public List<IntegerContext> integer() {
			return getRuleContexts(IntegerContext.class);
		}
		public IntegerContext integer(int i) {
			return getRuleContext(IntegerContext.class,i);
		}
		public List<RegisterContext> register() {
			return getRuleContexts(RegisterContext.class);
		}
		public RegisterContext register(int i) {
			return getRuleContext(RegisterContext.class,i);
		}
		public List<VarContext> var() {
			return getRuleContexts(VarContext.class);
		}
		public VarContext var(int i) {
			return getRuleContext(VarContext.class,i);
		}
		public OutputsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_outputs; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).enterOutputs(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FSMListener ) ((FSMListener)listener).exitOutputs(this);
		}
	}

	public final OutputsContext outputs() throws RecognitionException {
		OutputsContext _localctx = new OutputsContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_outputs);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(130);
			match(OUTPUT);
			setState(137); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				setState(137);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
				case 1:
					{
					setState(131);
					integer();
					setState(132);
					register();
					}
					break;
				case 2:
					{
					setState(134);
					integer();
					setState(135);
					var();
					}
					break;
				}
				}
				setState(139); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEGATIVEINT || _la==INT );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\33\u0090\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\3\2\3\2\3\2\3\2\6"+
		"\2%\n\2\r\2\16\2&\3\2\3\2\3\2\3\3\3\3\5\3.\n\3\3\3\3\3\3\4\3\4\3\4\5\4"+
		"\65\n\4\3\4\3\4\3\4\3\5\3\5\3\5\3\5\3\5\7\5?\n\5\f\5\16\5B\13\5\3\5\7"+
		"\5E\n\5\f\5\16\5H\13\5\3\5\3\5\3\6\3\6\3\6\5\6O\n\6\3\7\3\7\3\7\3\7\3"+
		"\7\3\b\3\b\3\t\3\t\3\t\5\t[\n\t\3\n\5\n^\n\n\3\n\3\n\3\n\3\13\5\13d\n"+
		"\13\3\13\3\13\5\13h\n\13\3\13\5\13k\n\13\3\13\3\13\3\f\3\f\3\f\3\r\3\r"+
		"\3\r\3\16\3\16\3\16\5\16x\n\16\3\17\3\17\3\17\3\17\3\17\3\17\3\17\6\17"+
		"\u0081\n\17\r\17\16\17\u0082\3\20\3\20\3\20\3\20\3\20\3\20\3\20\6\20\u008c"+
		"\n\20\r\20\16\20\u008d\3\20\2\2\21\2\4\6\b\n\f\16\20\22\24\26\30\32\34"+
		"\36\2\4\3\2\f\17\3\2\30\31\2\u0093\2 \3\2\2\2\4+\3\2\2\2\6\61\3\2\2\2"+
		"\b9\3\2\2\2\nK\3\2\2\2\fP\3\2\2\2\16U\3\2\2\2\20Z\3\2\2\2\22]\3\2\2\2"+
		"\24c\3\2\2\2\26n\3\2\2\2\30q\3\2\2\2\32t\3\2\2\2\34y\3\2\2\2\36\u0084"+
		"\3\2\2\2 !\7\3\2\2!\"\5\34\17\2\"$\5\36\20\2#%\5\b\5\2$#\3\2\2\2%&\3\2"+
		"\2\2&$\3\2\2\2&\'\3\2\2\2\'(\3\2\2\2()\7\4\2\2)*\7\2\2\3*\3\3\2\2\2+-"+
		"\7\5\2\2,.\5\6\4\2-,\3\2\2\2-.\3\2\2\2./\3\2\2\2/\60\7\27\2\2\60\5\3\2"+
		"\2\2\61\64\7\6\2\2\62\65\5\22\n\2\63\65\5\24\13\2\64\62\3\2\2\2\64\63"+
		"\3\2\2\2\65\66\3\2\2\2\66\67\t\2\2\2\678\5\20\t\28\7\3\2\2\29:\7\27\2"+
		"\2:@\7\7\2\2;?\5\n\6\2<?\5\f\7\2=?\5\26\f\2>;\3\2\2\2><\3\2\2\2>=\3\2"+
		"\2\2?B\3\2\2\2@>\3\2\2\2@A\3\2\2\2AF\3\2\2\2B@\3\2\2\2CE\5\4\3\2DC\3\2"+
		"\2\2EH\3\2\2\2FD\3\2\2\2FG\3\2\2\2GI\3\2\2\2HF\3\2\2\2IJ\7\b\2\2J\t\3"+
		"\2\2\2KN\5\22\n\2LO\5\32\16\2MO\5\f\7\2NL\3\2\2\2NM\3\2\2\2O\13\3\2\2"+
		"\2PQ\7\22\2\2QR\5\20\t\2RS\7\t\2\2ST\5\20\t\2T\r\3\2\2\2UV\t\3\2\2V\17"+
		"\3\2\2\2W[\5\16\b\2X[\5\22\n\2Y[\5\24\13\2ZW\3\2\2\2ZX\3\2\2\2ZY\3\2\2"+
		"\2[\21\3\2\2\2\\^\7\31\2\2]\\\3\2\2\2]^\3\2\2\2^_\3\2\2\2_`\7\24\2\2`"+
		"a\7\26\2\2a\23\3\2\2\2bd\7\31\2\2cb\3\2\2\2cd\3\2\2\2de\3\2\2\2eg\7\25"+
		"\2\2fh\7\n\2\2gf\3\2\2\2gh\3\2\2\2hj\3\2\2\2ik\7\13\2\2ji\3\2\2\2jk\3"+
		"\2\2\2kl\3\2\2\2lm\7\26\2\2m\25\3\2\2\2no\5\24\13\2op\5\30\r\2p\27\3\2"+
		"\2\2qr\7\22\2\2rs\5\16\b\2s\31\3\2\2\2tw\7\22\2\2ux\5\16\b\2vx\5\22\n"+
		"\2wu\3\2\2\2wv\3\2\2\2x\33\3\2\2\2y\u0080\7\20\2\2z{\5\16\b\2{|\5\22\n"+
		"\2|\u0081\3\2\2\2}~\5\16\b\2~\177\5\24\13\2\177\u0081\3\2\2\2\u0080z\3"+
		"\2\2\2\u0080}\3\2\2\2\u0081\u0082\3\2\2\2\u0082\u0080\3\2\2\2\u0082\u0083"+
		"\3\2\2\2\u0083\35\3\2\2\2\u0084\u008b\7\21\2\2\u0085\u0086\5\16\b\2\u0086"+
		"\u0087\5\22\n\2\u0087\u008c\3\2\2\2\u0088\u0089\5\16\b\2\u0089\u008a\5"+
		"\24\13\2\u008a\u008c\3\2\2\2\u008b\u0085\3\2\2\2\u008b\u0088\3\2\2\2\u008c"+
		"\u008d\3\2\2\2\u008d\u008b\3\2\2\2\u008d\u008e\3\2\2\2\u008e\37\3\2\2"+
		"\2\23&-\64>@FNZ]cgjw\u0080\u0082\u008b\u008d";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}