public class Comp extends VerilogComp {
    private Var flag;
    private VerilogComp comp;
    private VerilogComp comp2;
    private String opp;

    public Comp(Var flag, VerilogComp comp, VerilogComp comp2, String opp) {
        super("comp_" + comp.getName() + "and" + comp2.getName(), comp.getBitSize(), false, false);
        this.flag = flag;
        this.comp = comp;
        this.comp2 = comp2;
        this.opp = opp;
    }

    @Override
    public String defineComp() {
        if (this.opp.equals("equals"))
            return "assign " + flag.getName() + " = (" + comp.getName() + "==" + comp2.getName() + ")? 1'b1:1'b0";
        else if (this.opp.equals("less than"))
            return "assign " + flag.getName() + " = (" + comp.getName() + "<" + comp2.getName() + ")? 1'b1:1'b0";
        else if (this.opp.equals("greater than"))
            return "assign " + flag.getName() + " = (" + comp.getName() + ">" + comp2.getName() + ")? 1'b1:1'b0";
        else if (this.opp.equals("not equals"))
            return "assign " + flag.getName() + " = (" + comp.getName() + "!=" + comp2.getName() + ")? 1'b1:1'b0";
        return "";

    }


}
