import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;


public class RunProgram {
    public static void main(String[] args) {
        try
        {
            FSMLexer lexer = new FSMLexer(CharStreams.fromFileName("sampleFSm.txt"));
            FSMParser parser = new FSMParser(new CommonTokenStream(lexer));
           ProgramListener listener = new ProgramListener("sampleFsm.txt");
            ParseTreeWalker.DEFAULT.walk(listener,parser.fsm());
        }
        catch (java.io.IOException e) {
            System.out.println("IOException sorry");
        }
    }
}
