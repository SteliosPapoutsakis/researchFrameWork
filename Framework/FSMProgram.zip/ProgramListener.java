/*
this class is the Listener that goes through the parser tree and takes out all the relivent info,
with that info it hands off the data to other classes and then prints that info to a ".v" file at the end

@author Stelios Papoutsakis
 */

import jdk.nashorn.internal.parser.DateParser;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

public class ProgramListener extends FSMBaseListener {

    private String programName; // name of file
    private ArrayList<VerilogComp> comps = new ArrayList<>(); // List of all Verilog comps
    private HashMap<Register, ArrayList<VerilogComp>> regInputs = new HashMap<>(); // map of regester and its repective inputs
    private HashMap<Var, Integer> assignments = new HashMap<>(); // map of varibles and there respective int assignemts
    private HashMap<Var, Integer> conditions = new HashMap<>(); // map of flags and there respective next states
    private ArrayList<State> states = new ArrayList<>(); // List of states

    //ctor
    public ProgramListener(String fileName) {
        this.programName = fileName.substring(0, fileName.length() - 4);
    }


    @Override
    public void exitState(FSMParser.StateContext ctx) {
        // for every variable that has an assigmnet in this state
        for (int i = 0; i < ctx.var_assign().size(); i++) {
            //find the variable
            FSMParser.Var_assignContext varAssign = ctx.var_assign(i);
            Var var = (Var) findComp(varAssign.var().NAME().getText());

            //find the int value that it is assigned to
            int num = Integer.parseInt(varAssign.var_assigment().integer().getText());
            this.assignments.put(var, num);
        }

        //find the statenumber and make the new state
        String temp = ctx.STATENUMBER().getText();
        int temp2 = Integer.parseInt(temp.substring(6, temp.length()));
        State state = new State(temp2, new HashMap<>(this.assignments), new HashMap<>(this.conditions));
        this.states.add(state);
        //clear maps for new state
        this.assignments.clear();
        this.conditions.clear();


    }


    @Override
    public void enterInputs(FSMParser.InputsContext ctx) {
        // for every integer context in the input rule...
        for (int i = 0; i < ctx.getChildCount(); i++) {
            if (ctx.getChild(i) instanceof FSMParser.RegisterContext) {
                // if defining a new register
                FSMParser.RegisterContext regcont = (FSMParser.RegisterContext) ctx.getChild(i);
                Register reg = new Register(regcont.NAME().getText(), Integer.parseInt(ctx.getChild(i - 1).getText()),
                        true, false);
                //this.input.add(reg);
                this.comps.add(reg);
                this.regInputs.put(reg, new ArrayList<>());
                //if defining a new Variable
            } else if (ctx.getChild(i) instanceof FSMParser.VarContext) {
                FSMParser.VarContext varCont = (FSMParser.VarContext) ctx.getChild(i);

                // if this varaible is a clock (labled with C_)
                if (varCont.Clk() != null) {
                    Var var = new Var(varCont.NAME().getText(), Integer.parseInt(ctx.getChild(i - 1).getText())
                            , true,
                            false, false);
                    VerilogComp.setClkName(var.getName());


                    // if this varible is a reset(labled with R_)
                } else if (varCont.RESET() != null) {
                    Var var = new Var(varCont.NAME().getText(), Integer.parseInt(ctx.getChild(i - 1).getText())
                            , true,
                            false, false);
                    VerilogComp.setResetName(var.getName());

                }
                // else just a standard variable
                else {
                    Var var = new Var(varCont.NAME().getText(), Integer.parseInt(ctx.getChild(i - 1).getText()), true,
                            false, false);
                    // this.input.add(var);
                    this.comps.add(var);
                }
            }

        }


    }

    @Override
    public void enterOutputs(FSMParser.OutputsContext ctx) {
        //for every varible label as an output
        for (int i = 0; i < ctx.getChildCount(); i++) {
            //if it is a register
            if (ctx.getChild(i) instanceof FSMParser.RegisterContext) {

                //find it
                FSMParser.RegisterContext regcont = (FSMParser.RegisterContext) ctx.getChild(i);
                Register reg = new Register(regcont.NAME().getText(), Integer.parseInt(ctx.getChild(i - 1).getText()),
                        false, true);
                this.comps.add(reg);
                this.regInputs.put(reg, new ArrayList<>());

                //else if it is a variable
            } else if (ctx.getChild(i) instanceof FSMParser.VarContext) {
                FSMParser.VarContext varCont = (FSMParser.VarContext) ctx.getChild(i);
                Var var = new Var(varCont.NAME().getText(), Integer.parseInt(ctx.getChild(i - 1).getText()), false,
                        true, false);
                //this.outputs.add(var);
                this.comps.add(var);
            }

        }


    }

    public void enterRegister_assign(FSMParser.Register_assignContext ctx) {
        // if the register doesn't exist, make a new one
        if (findComp(ctx.register().NAME().getText()) == null) {
            Register temp = new Register(ctx.register().NAME().getText(),
                    Integer.parseInt(ctx.register().INT().getText()), false, false);
            this.comps.add(temp);
            this.regInputs.put(temp, new ArrayList<>());

        }


    }

    @Override
    public void enterVar_assign(FSMParser.Var_assignContext ctx) {
        //if variable doesn't exist, make it
        if (findComp(ctx.var().NAME().getText()) == null) {
            Var temp = new Var(
                    ctx.var().NAME().getText(),
                    Integer.parseInt(ctx.var().INT().getText()),
                    false, false, false);
            this.comps.add(temp);
        }


    }

    @Override
    public void enterVar_assigment(FSMParser.Var_assigmentContext ctx) {
        // this nodes parent was an instance of var_Assign
        if (ctx.getParent() instanceof FSMParser.Var_assignContext) {

            //find the variable and add it to the assignments map
            FSMParser.Var_assignContext varCont = (FSMParser.Var_assignContext) ctx.getParent();
            Var var = (Var) findComp(varCont.var().NAME().getText());
            this.assignments.put(var,Integer.parseInt(ctx.integer().getText()));

        }


    }

    @Override
    public void enterAdder_assign(FSMParser.Adder_assignContext ctx) {
        Register reg = null;
        // if this is coming from a Register_Assign context
        if (ctx.getParent() instanceof FSMParser.Register_assignContext) {

            // making adder
            FSMParser.Register_assignContext regCont = (FSMParser.Register_assignContext) ctx.getParent();
            reg = (Register) findComp(regCont.register().NAME().getText());
            Adder temp = new Adder("Adder_" + reg.getName(), reg.getBitSize());
            this.comps.add(temp);
            this.regInputs.get(reg).add(temp);

            // finding 1st input for adder
            if (ctx.component(0).register() != null)
                temp.addInput(findComp(ctx.component(0).register().NAME().getText()), 0);
            else if (ctx.component(0).integer() != null)
                temp.addInput(new FixedNumber(Integer.parseInt(ctx.component(0).integer().getText()), reg.getBitSize()), 0);
            else if (ctx.component(0).var() != null)
                temp.addInput(findComp(ctx.component(0).var().getText()), 0);

            //finding second input for adder
            if (ctx.component(1).register() != null)
                temp.addInput(findComp(ctx.component(1).register().NAME().getText()), 1);
            else if (ctx.component(1).integer() != null)
                temp.addInput(new FixedNumber(Integer.parseInt(ctx.component(1).integer().getText()), reg.getBitSize()), 1);
            else if (ctx.component(1).var() != null)
                temp.addInput(findComp(ctx.component(1).var().getText()), 1);


        }

    }


    @Override
    public void enterReg_assigment(FSMParser.Reg_assigmentContext ctx) {
       //if nodes parent was a register_assign node
        if (ctx.getParent() instanceof FSMParser.Register_assignContext) {
            FSMParser.Register_assignContext regCont = (FSMParser.Register_assignContext) ctx.getParent();
            Register reg = (Register) findComp(regCont.register().NAME().getText());
            //if register, assign register
            if (ctx.register() != null) {
                this.regInputs.get(reg).add(findComp(ctx.register().NAME().getText()));
            } else if (ctx.integer() != null) {
                //if int assign an int
                this.regInputs.get(reg).add(new FixedNumber(Integer.parseInt(
                        ctx.integer().getText()), reg.getBitSize()));

            }
        }
    }


    @Override
    public void enterCondition(FSMParser.ConditionContext ctx) {
        // generates a flag input for each unique condition
        String text = ctx.getText();
        text.replace(" ", "");
        //if there is no flag for this condition, make a variable and give it to conditions map
        if (findComp("flag_" + text) == null) {
            Var output = new Var("flag_" + text,
                    1, false, true, false);

            FSMParser.Next_stateContext context = (FSMParser.Next_stateContext) ctx.getParent();
            int nextState = Integer.parseInt(
                    context.STATENUMBER().getText().substring(6, context.STATENUMBER().getText().length()));
            this.conditions.put(output, nextState);
            this.comps.add(output);
            VerilogComp compare1 = null;
            VerilogComp compare2 = null;
             if(ctx.register() != null)
             {
                 compare1 = findComp(ctx.register().NAME().getText());

             }
             else{
                 compare1 = findComp(ctx.var().NAME().getText());
             }

            if(ctx.component().var() != null)
            {
                compare2 = findComp(ctx.component().var().NAME().getText());
            }
            else if(ctx.component().integer() != null)
            {
                compare2 =  new FixedNumber(Integer.parseInt(ctx.component().integer().getText()));
            }
            else
            {
                compare2 = findComp(ctx.component().register().NAME().getText());
            }


            this.comps.add(new Comp(output,compare1,compare2,ctx.opp.getText()));






        }

    }

    @Override public void exitNext_state(FSMParser.Next_stateContext ctx) {
        // if no conditions, make a dummy variable with the next state number;
        if(ctx.condition() == null)
        {
            Var var = new Var("NO_CONDITIONS",1,false,false,false);
            this.conditions.put(var,Integer.parseInt(ctx.STATENUMBER().getText().substring(6,ctx.STATENUMBER().getText().length())));
        }
    }

    @Override
    public void exitFsm(FSMParser.FsmContext ctx) {
        ArrayList<Mux> muxes = new ArrayList<>();
        HashMap<Mux, ArrayList<VerilogComp>> muxIn = new HashMap<>();




        for (VerilogComp comp : this.comps) {

            // for every component thats a register, make a mux for it
            if (comp instanceof Register) {
                Register reg = (Register) comp;
                ArrayList<VerilogComp> inputs = this.regInputs.get(reg);
                //find the size of the mux
                int size = getMuxSize(inputs);
                Mux mux = new Mux(size, reg.getBitSize(), reg);
                int i = 0;
                // add the inputs to each mux from the register
                for (VerilogComp comp2 : inputs) {
                    mux.addInput(comp2, i);
                    i++;
                }
                muxes.add(mux);
                muxIn.put(mux, inputs);


            }
        }
        int size = 0;
// find the total size of all the selections bit
        for (Mux mux : muxes) {
            this.comps.add(mux);
            size += mux.getSelectionSize();
        }
        Var var = new Var("SelectionBits", size, true, false, true);
        this.comps.add(var);
        var.defineAssign(muxes);

// for every state add the size and muxIn
        for (State state : this.states) {
            state.setSelect(muxIn, size);
        }
// write files
        displayFileDataPath(muxes);
        displayFileContoller();
    }

/*
FIND BETTER ALGORITHM FOR THISSSS
@purpose to find the size of a certin mux based on inputs
@return size
 */
    public int getMuxSize(ArrayList<VerilogComp> inputs) {
        int size = IntToBinary.strickBinary(inputs.size()-1).length();
        switch (size)
        {
            case 1:
                return 2;
            case 2:
                return 4;
            case 3:
                return 8;

        }
        return 16;
    }
/*
@purpose to find a Verilog component given a name
@return the component
 */
    public VerilogComp findComp(String name) {
        for (VerilogComp comp : this.comps) {
            if (comp.getName().equals(name))
                return comp;
        }
        return null;
    }


    // method that takes the ArrayList of Verilog comps and muxes and prints every line ot in order
    public void displayFileDataPath(ArrayList<Mux> muxes) {
        try {

            //define all these String which is where the verilog code lines go into
            PrintWriter file = new PrintWriter(this.programName + "_DataPath.v");
            StringBuilder header = new StringBuilder().append("module " + this.programName + "(");
            StringBuilder outputHeader = new StringBuilder();
            StringBuilder inputHeader = new StringBuilder();
            StringBuilder inputs = new StringBuilder();
            StringBuilder outputs = new StringBuilder();
            StringBuilder reg = new StringBuilder();
            StringBuilder wire = new StringBuilder();
            StringBuilder comps = new StringBuilder();
            StringBuilder assign = new StringBuilder();
            StringBuilder flipflop = new StringBuilder();

            boolean hasReg = false;

           //for ever component
            for (VerilogComp comp : this.comps) {
                //if variable and a select signal, write assign statments
                if (comp instanceof Var) {
                    Var var = (Var) comp;
                    if (var.isSelectSignal())
                        assign.append(var.defineAssign(muxes) + "\n");

                }

               //if there is a regester, define FF at the end of file
                if (comp instanceof Register) {
                    hasReg = true;


                }

                if (!(comp.defineInput().equals(""))) {
                    if (comp instanceof Register) {
                        inputHeader.append(comp.getName() + ",");
                        inputs.append(comp.defineInput() + "\n");
                    } else if (comp instanceof Var) {
                        Var var = (Var) comp;
                        if (var.isSelectSignal()) {
                            inputHeader.append(comp.getName() + ",");
                            inputs.append(comp.defineInput() + "\n");
                        }

                    }

                }
                if (!(comp.defineOutput().equals(""))) {
                    if(comp instanceof Register) {
                        outputHeader.append(comp.getName() + ",");
                        outputs.append(comp.defineOutput() + "\n");
                    }
                    else if(comp.getName().substring(0,4).equals("flag"))
                    {
                        outputHeader.append(comp.getName() + ",");
                        outputs.append(comp.defineOutput() + "\n");
                    }
                }
                if (!(comp.defineReg().equals("")))
                    reg.append(comp.defineReg() + "\n");
                if (!(comp.defineWire().equals("")))
                    wire.append(comp.defineWire() + "\n");
                if (!(comp.defineComp().equals("")))
                    comps.append(comp.defineComp() + "\n");
                if (!(comp.defineFlipFlop().equals("")))
                    flipflop.append(comp.defineFlipFlop() + "\n");


            }

            header.append(outputHeader.append(inputHeader));
            file.println(header + VerilogComp.getClkName() + "," + VerilogComp.getResetName() + ")" + "\n");
            file.println(outputs + "\n");
            file.println(inputs + "\n");
            file.println(reg + "\n");
            file.println(wire + "\n");
            file.println(assign + "\n");
            file.println(comps + "\n");
            file.println(flipflop + "\n");
            file.println("endmodule" + "\n");

            // if this files contains a register, print this added module
            if (hasReg) {
                file.println("module DFFR(output reg[SIZE-1:0] q, input[SIZE-1:0] d, input clk , input rst" +
                        ",input[SIZE-1:0] rst_next);");
                file.println("parameter SIZE = 8;");
                file.println("always_ff @(posedge clk, posedge rst)");
                file.println("begin");
                file.println("if(rst) q <= rst_next;");
                file.println("else q <= d;");
                file.println("end");
                file.println("endmodule");

            }
            file.close();
        } catch (FileNotFoundException e) {
            System.out.println("File error");
        }


    }


    public void displayFileContoller() {
        try {
            PrintWriter file = new PrintWriter(this.programName + "_Contoller.v");
            StringBuilder header = new StringBuilder("module " + this.programName + "_Controller(");
            StringBuilder inputs = new StringBuilder();
            StringBuilder outputs = new StringBuilder();
            StringBuilder reset = new StringBuilder("always @ (posedge " + VerilogComp.getClkName() + ", posedge " +
                    VerilogComp.getResetName() + ")\n");
            reset.append("begin\n");
            reset.append("if(" + VerilogComp.getResetName() + ")" + "\n");
            reset.append("begin\n");
            StringBuilder states = new StringBuilder("always @ (*)\n begin\n\ncase(state)\n");


            for (VerilogComp comp : this.comps) {
                if (!(comp.defineInput().equals("")) && comp instanceof Var) {
                    if (((Var) comp).isSelectSignal()) {
                        Var var = (Var) comp;
                        var.setOutput(true);
                        var.setInput(false);
                        outputs.append(comp.defineOutput() + "\n");
                        int size = var.getBitSize() - 1;
                        var.setName(size,0);
                        size++;
                        reset.append(var.getName() + " = " + size + "b'0;\n");
                        reset.append("\tend\nend\n");
                    } else inputs.append(comp.defineInput() + "\n");


                    header.append(comp.getName() + ",");


                }
                if (!(comp.defineOutput().equals("")) && comp instanceof Var) {
                    Var var = (Var) comp;
                    if (var.getName().substring(0, 4).equals("flag")) {
                        var.setInput(true);
                        var.setOutput(false);
                        inputs.append(var.defineInput() + "\n");
                    } else if(!var.isSelectSignal())
                        outputs.append(var.defineOutput() + "\n");
                    header.append(comp.getName() + ",");
                }
            }

            int size = IntToBinary.strickBinary(this.states.size()).length();
            int sizeOfReg = size-1;
            String name = "reg state,";
            String name2 = "next_state;";
            if (size > 1) {
                name = "reg state[" + sizeOfReg + ":0], ";
                name2 = "next_state[" + sizeOfReg + ":0];";
            }
            outputs.append(name + name2 + "\n");
            for (State state : this.states) {
                state.setbinarystatenumber(size);
                states.append(state.defState() + "\n");
            }

            states.append("endcase\nend\n");

            file.println(header.toString().substring(0, header.length() - 1) + ")");
            file.println(inputs);
            file.println(outputs);
            file.println(reset);
            file.println(states);
            file.close();

        } catch (FileNotFoundException e) {
            System.out.println("error creating file in controller path");
        }

    }


}
