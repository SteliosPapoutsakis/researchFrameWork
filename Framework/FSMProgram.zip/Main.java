/*
This class is used to take all the verilog comp objects and print them to a file,
basically for testing purposes
 *//*

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Register R1 = new Register("R1", 8, true, false);
        Var N = new Var("N", 8, true, false, false);
        Var muxSelections = new Var("MuxSelections", 4, true, false, true);
        Var flag = new Var("flag", 90, false, true, false);
        Register R0 = new Register("R0", 8, false, false);
        Register A = new Register("A", 234, false, false);
        Adder add = new Adder("Adder1", 8);
        add.addInput(A, 0);
        add.addInput(new FixedNumber(-5, add.getBitSize()), 1);
        Adder add2 = new Adder("Adder2", 8);
        add2.addInput(R0, 0);
        add2.addInput(R1, 1);
        Mux mux1 = new Mux(4, 8, R0);
        mux1.addInput(new FixedNumber(0, add.getBitSize()), 0);
        mux1.addInput(R1, 1);
        mux1.addInput(new FixedNumber(1, add.getBitSize()), 2);
        mux1.addInput(R0, 3);
        Mux mux2 = new Mux(4, 8, R1);
        mux2.addInput(new FixedNumber(0, add2.getBitSize()), 0);
        mux2.addInput(add2, 1);
        mux2.addInput(new FixedNumber(1, add2.getBitSize()), 2);
        mux2.addInput(R1, 3);


        ArrayList<VerilogComp> comp = new ArrayList<>();
        ArrayList<Mux> muxes = new ArrayList<>();
        comp.add(R0);
        comp.add(R1);
        comp.add(A);
        comp.add(add);
        comp.add(add2);
        comp.add(N);
        comp.add(mux1);
        comp.add(mux2);
        comp.add(flag);
        comp.add(muxSelections);
        muxes.add(mux1);
        muxes.add(mux2);

       displayFileDataPath(comp,muxes,"output.v");
    }

// method that takes the ArrayList of Verilog comps and muxes and prints every line ot in order
    public static void displayFileDataPath(ArrayList<VerilogComp> compList, ArrayList<Mux> muxes, String fileName) {
        try {
            PrintWriter file = new PrintWriter(new File(fileName));
            String header = "module FibData(";
            String outputHeader = "";
            String inputHeader = "";
            String inputs = "";
            String outputs = "";
            String reg = "";
            String wire = "";
            String comps = "";
            String assign = "";
            String flipflop = "";
            boolean hasReg = false;

            for (VerilogComp comp : compList) {
                if (comp instanceof Var) {
                    Var select = (Var) comp;
                    if (select.isSelectSignal() == true)
                        assign = select.defineAssign(muxes) + "\n";
                }

                if (comp instanceof Register) {
                    hasReg = true;
                }

                if (!(comp.defineInput().equals(""))) {
                    inputHeader += comp.getName() + ",";
                    inputs += comp.defineInput() + "\n";
                }
                if (!(comp.defineOutput().equals(""))) {
                    outputHeader += comp.getName() + ",";
                    outputs += comp.defineOutput() + "\n";
                }
                if (!(comp.defineReg().equals("")))
                    reg += comp.defineReg() + "\n";
                if (!(comp.defineWire().equals("")))
                    wire += comp.defineWire() + "\n";
                if (!(comp.defineComp().equals("")))
                    comps += comp.defineComp() + "\n";
                if (!(comp.defineFlipFlop().equals("")))
                    flipflop += comp.defineFlipFlop() + "\n";


            }

            inputHeader += "clk,reset);";
            header += outputHeader + inputHeader;
            inputs+="input clk,reset;" + "\n";

            file.println(header);
            file.println(outputs + "\n");
            file.println(inputs + "\n");
            file.println(reg + "\n");
            file.println(wire + "\n");
            file.println(assign + "\n");
            file.println(comps + "\n");
            file.println(flipflop + "\n");
            file.println("endmodule" + "\n");

            // if this files contains a register, print this added module
            if (hasReg) {
                file.println("module DFFR(output reg[SIZE-1:0] q, input[SIZE-1:0] d, input clk, input rst" +
                        ",input[SIZE-1:0] rst_next);");
                file.println("parameter SIZE = 8;");
                file.println("always_ff @(posedge clk, posedge rst)");
                file.println("begin");
                file.println("if(rst) q <= rst_next;");
                file.println("else q <= d;");
                file.println("end");
                file.println("endmodule");

            }
            file.close();
        }
        catch (FileNotFoundException e)
        {
            System.out.println("File error");
        }


    }

}

*/
