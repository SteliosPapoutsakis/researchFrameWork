/*
This class is used to describe a Mux in verilog
This class takes the info and prints the appropriate
verilog code

@author Stelios Papoutsakis
*/


public class Mux extends VerilogComp {
    private VerilogComp[] inputs; // array of the inputs to the mux
    private int selectionSize = 0; // size of the select bits
    private Register input; // register whose mux outputs to it
    private int size; // size of mux

    public Mux(int size, int bitSize, Register input) {
        super("mux" + input.getName(), bitSize, false, false);
        this.input = input;
        this.size = size;
        int i = size;
        // calculating size of array based on size of mux
        while (i != 1) {
            i = i / 2;
            this.selectionSize++;
        }
        this.inputs = new VerilogComp[this.getBitSize()];
    }

    /*
Overriden methods which write verilog code
 */


    @Override
    public String defineWire() {
        int bit = this.selectionSize - 1;
        String str = "";
        if (bit > 1)
            str = "[" + bit + ":0] ";
        return "wire " + str + this.getName() + "_Select;";
    }

    @Override
    public String defineComp() {
        String str = "mux" + this.getBitSize()
                + " " + this.getName() + "(" + this.input.getName() + "_next, ";
        int count = 0;
        // loops to see how many inputs the mux has
        for (VerilogComp comp : this.inputs) {
            if (comp == null) continue;
            str += comp.getName();
            count++;
            if (!(count == this.inputs.length - 1))
                str += ", ";
        }
        // if inputs don't match the size, fill it with "," and empty parameters
        while (count < this.size) {
            str += ", ";
            count++;

        }
        str += this.getName() + "_Select);";
        return str;

    }


    // adding inputs for the muxes
    public void addInput(VerilogComp comp, int index) {
        if (Math.abs(index) >= this.size) {
            System.out.println("Error index too big");
            return;
        }
        for (VerilogComp comp2 : this.inputs) {
            if (comp2 == null) continue;
            if (comp2.getName().equals(comp.getName()))
                return;
        }
        this.inputs[index] = comp;
    }


    public Register getInput() {
        return input;
    }

    public int getSize() {
        return size;
    }


    public static void main(String[] args) {

    }

    public VerilogComp[] getInputs() {
        return inputs;
    }


    public int getSelectionSize() {
        return selectionSize;
    }


}
